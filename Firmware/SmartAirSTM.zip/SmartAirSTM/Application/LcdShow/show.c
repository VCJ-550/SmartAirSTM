#include "show.h"
#include "lcd.h"
#include "pic.h"
#include "lcd_init.h"
#include "delay.h"
#include "Sensor.h"
#include "app.h"

//ShowTidDef ShowTidStr;

uint8_t strt[4096];


//��ȫ��
//Ĭ��Ϊ����ɫ
void LCD_Clear()
{
 LCD_Fill(0,0,LCD_W,LCD_H,BACK_COLOR);
}
	
//��ʾ��ӭҳ��
void Show_Welcome(void)
{
 //��ʾ�ַ�
//	uint8_t i,j;
//	float t=0;
//	POINT_COLOR=RED;
//	BACK_COLOR = YELLOW;
//  Show_Str(10,10,200,24,"�о�԰����",24,0);	
//	BACK_COLOR = WHITE;
//	LCD_ShowString(0,40,"LCD_W:",RED,WHITE,16,0);
//	LCD_ShowIntNum(48,40,LCD_W,3,RED,WHITE,16);
//	LCD_ShowString(80,40,"LCD_H:",RED,WHITE,16,0);
//	LCD_ShowIntNum(128,40,LCD_H,3,RED,WHITE,16);
//	LCD_ShowString(80,40,"LCD_H:",RED,WHITE,16,0);
//	LCD_ShowString(0,70,"Increaseing Nun:",RED,WHITE,16,0);
//	LCD_ShowFloatNum1(128,70,t,4,RED,WHITE,16);
//	t+=0.11;
//	delay_ms(1000);
//	LCD_Fill(0,0,LCD_W,LCD_H,WHITE);

 LCD_ShowFPicture(0,0,240,320,MapDepotStr.mainpage);
//	delay_ms(500);
//	LCD_Clear();
}

void ShowSensorPage(void)
{
 if(SystemStr.ShowUiUpdata)  //��Ҫ���ؽ���
 {
	 LCD_Fill(8,64,144,226,WHITE);
	 LCD_ShowString(10,64,"CO2:     ppm",RED,WHITE,16,1);
   LCD_ShowString(10,80,"Tem:      C",RED,WHITE,16,1);
   LCD_ShowString(10,96,"Hum:       %",RED,WHITE,16,1);	 
   LCD_ShowString(10,112,"Light:     lx",RED,WHITE,16,1);
	 LCD_ShowString(10,128,"Noise:      V",RED,WHITE,16,1);
   LCD_ShowString(10,144,"CH4O:     ug/m3",RED,WHITE,16,1);		 
   LCD_ShowString(10,160,"PM1:     ug/m3",RED,WHITE,16,1); 
   LCD_ShowString(10,176,"PM2.5:     ug/m3",RED,WHITE,16,1);  
	 LCD_ShowString(10,192,"PM10:     ug/m3",RED,WHITE,16,1); 	 
	 LCD_ShowString(10,208,"BTVot:     V",RED,WHITE,16,1); 
	 ShowLogoInfo("����ҳ����سɹ�");
	 SystemStr.ShowUiUpdata = 0;
 }
 LCD_ShowIntNum(42,64,SensorDataStr.CO2Value,4,RED,WHITE,16);
 LCD_ShowDecimalsNum1(42,80,SensorDataStr.HDCStr.Temperature,2,2,RED,WHITE,16);
 LCD_ShowDecimalsNum1(42,96,SensorDataStr.HDCStr.Humidity,2,2,RED,WHITE,16);
 LCD_ShowIntNum(42,112,SensorDataStr.Light,4,RED,WHITE,16);
 LCD_ShowINntDecNum1(58,128,SensorDataStr.Noise,2,2,RED,WHITE,16); 
 LCD_ShowIntNum(50,144,SensorDataStr.WZSStr.WZSCHValue,4,RED,WHITE,16);
 LCD_ShowIntNum(50,160,SensorDataStr.PMSStr.PM1Value,4,RED,WHITE,16);
 LCD_ShowIntNum(58,176,SensorDataStr.PMSStr.PM2_5Value,4,RED,WHITE,16); 
 LCD_ShowIntNum(50,192,SensorDataStr.PMSStr.PM10Value,4,RED,WHITE,16);
 LCD_ShowINntDecNum1(58,208,SensorDataStr.BTVotValue,2,2,RED,WHITE,16);
}

void ShowWifiPage(uint16_t x,uint16_t y)
{	
	LCD_ShowString(x,y,"                                  ",POINT_COLOR,BACK_COLOR,16,0); 
	switch(SystemStr.WifiRunMode)
	{
    case 0: Show_Str(x,y,200,24,"smartconfig����״̬",16,0); break;      
    case 1: Show_Str(x,y,200,24,"AP����״̬",16,0); break;       
    case 2: Show_Str(x,y,200,24,"WIFI�����õ�δ����·����",16,0); break;       
    case 3: Show_Str(x,y,200,24,"WIFI������������·����",16,0); break;        
    case 4:	Show_Str(x,y,200,24,"������·���������ӵ��ƶ�",16,0); break;        
    case 5: Show_Str(x,y,200,24,"WIFI�豸���ڵ͹���ģʽ",16,0); break;               
    case 6:	Show_Str(x,y,200,24,"WIFI�豸����smartconfig&AP����״̬",16,0); break;
		
    default:break;
	}
}

//��ʾ��ҳ
void ShowHomePage(uint16_t inc)
{
	if(SystemStr.ShowUiUpdata)
	{
		ShowLogoInfo("��ҳ����سɹ�");
		SystemStr.ShowUiUpdata=0;
	}
  //ʱ��
	MainTimerShow();
	//����
	
	/*�ؼ�����*/	
	LCD_ShowDecimalsNum1(50,175,SensorDataStr.HDCStr.Temperature,2,2,RED,WHITE,16);//��ʪ��
  LCD_ShowDecimalsNum1(110,175,SensorDataStr.HDCStr.Humidity,2,2,RED,WHITE,16);
	//PM
	LCD_ShowIntNum(50,220,SensorDataStr.PMSStr.PM1Value,4,RED,WHITE,16);
  LCD_ShowIntNum(110,220,SensorDataStr.PMSStr.PM2_5Value,4,RED,WHITE,16); 
  LCD_ShowIntNum(170,220,SensorDataStr.PMSStr.PM10Value,4,RED,WHITE,16);
	//��ȩ
	LCD_ShowIntNum(50,270,SensorDataStr.WZSStr.WZSCHValue,4,RED,WHITE,16);
	//CO2
	 LCD_ShowIntNum(110,270,SensorDataStr.CO2Value,4,RED,WHITE,16);
	//����
  LCD_ShowINntDecNum1(170,270,SensorDataStr.Noise,2,2,RED,WHITE,16);  
}

void SetShowUi(uint8_t page)
{
  switch(page)
	{
	  case xqPage :   //����
       ShowSensorPage(); //ˢ����Ϣ
		break;
		case zyPage :  //��ҳ
       ShowHomePage(0);
			break;
		
		case szPage :  //����ҳ��
			
			break;
		
		case xxPage : //��Ϣҳ��
			
			break;
		
	  default : break;
	}

}

//��ӡ�����Ϣ
void ShowLogoInfo(uint8_t* str)
{ 
	uint16_t color,bcolor;
	
	bcolor = BACK_COLOR;
	color = POINT_COLOR;
	
	BACK_COLOR = WHITE;
	POINT_COLOR = BRRED;
	Show_Str(0,308,200,24,str,12,0);
	BACK_COLOR = bcolor;
	POINT_COLOR = color;
}


//��ӡ��Ϣ��ת��ר����ͿѻSDK(SDK��UTF-8���룬������GBK2312����)
void LogoGoto(uint8_t tid)
{
 switch(tid)
 {
	 //����ʱ��
   case 1: ShowLogoInfo("����ʱ���ȡ�ɹ�"); break;
	 case 2: ShowLogoInfo("����ʱ���ȡʧ�ܣ���������"); break;
	 case 3: ShowLogoInfo("�±��л�Ϊ���϶�"); break;
	 case 4: ShowLogoInfo("�±��л�Ϊ���϶�"); break;
	 default : break;
 }
}
	



	



