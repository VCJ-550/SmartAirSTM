#ifndef __LED_H
#define __LED_H	 
#include "sys.h"
 
#define LED PCout(8)// PC8

void LED_Init(void);//��ʼ��

		 				    
#endif
