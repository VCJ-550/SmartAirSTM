#include "key.h"
#include "delay.h"
#include "timer.h"

 static	uint8_t Ktimer=0;

void KEY_Init(void)
{
 GPIO_InitTypeDef  GPIO_InitStructure; 	
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);	 	
 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;//KEY-->PC10 
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD; //��������
 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//IO���ٶ�Ϊ50MHz
 GPIO_Init(GPIOC, &GPIO_InitStructure);					 
}

//����ɨ�裬֧�ֶ̰��ͳ���
uint8_t KEY_Scan(void)
{
	uint8_t t;
  if(!KEY)
	{
	 delay_ms(10);
	 if(!KEY)
		{
			Ktimer = SystemTimerOclk; //��¼��ǰʱ��			
			while(!KEY)
			{
        if(Ktimer>SystemTimerOclk) //ʱ�䱻����
					Ktimer = SystemTimerOclk;	
				else 
					t = SystemTimerOclk - Ktimer;
			  if(t>3) return KEY_LON;
			}	
			  return KEY_ON;
		}
	}
  return KEY_OFF;	
}

